#! /urs/bin/env python3
# coding=utf-8
import requests
import base64
from pprint import pprint
import hashlib
if __name__ == '__main__':

    with open('./cap_union_new_getcapbysig.jpg', 'rb') as img:
        image = img.read()
    url = 'http://222.186.170.51:7777/?username=l764191074&password=a731c1515e78f7247504679e97378922&captchacpid=1001?captcha'
    r = requests.post(url, data=image)

# if __name__ == '__main__':
#     url = 'http://api.xxiin.com/?plan=captcha&user=l764191074&pass=gs4771822&topic=7001&author=test'
#     with open('./cap_union_new_getcapbysig.jpg', 'rb') as img:
#         image = img.read()
#     r = requests.post(url, data={'Base': base64.b64encode(image)})
#     pprint(r.json())