#! /urs/bin/env python3
# coding=utf-8
import requests
import base64
from pprint import pprint
import json
import hashlib


def request_post(url, *p, **kwargs):
    try:

        r = requests.post(url, *p, **kwargs)
    except requests.exceptions.ConnectionError:
        return request_post(url, *p, **kwargs)
    return r


class YZM():

    def __init__(self, code_id):
        self.code_id = code_id

    def fengye(self, image):
        #  http://www.dama999.com/index/index/type
        if isinstance(image, str):
            with open(image, 'rb') as img:
                image = img.read()
        elif isinstance(image, bytes):
            pass
        url = 'http://222.186.170.51:7777/?username=l764191074&password=a731c1515e78f7247504679e97378922' \
              '&captchacpid={}?captcha'.format(self.code_id)

        r = request_post(url, data=image)
        return r.text

    def ok(self, image):
        #   http://www.xxiin.com/index/index/api.htm
        if isinstance(image, str):
            with open(image, 'rb') as img:
                image = img.read()
        elif isinstance(image, bytes):
            pass
        url = 'http://api.xxiin.com/?plan=captcha&user=l764191074&pass=gs4771822&topic={}&author=test'\
            .format(self.code_id)
        r = request_post(url, data={'Base': base64.b64encode(image)})
        test = r.text.replace('Date[', '{')
        test = test[0:-1] + '}'
        rtn = json.loads(test)
        pprint(rtn)
        return rtn['Result']
if __name__ == '__main__':

    with open('./cap_union_new_getcapbysig.jpg', 'rb') as img:
        image = img.read()
    #  http://www.dama999.com/index/index/type
    # y = YZM('1001')
    # y.fengye(image)
    # y = YZM('7001')
    # y.ok(image)


# if __name__ == '__main__':
     #   http://www.xxiin.com/index/index/api.htm
#     url = 'http://api.xxiin.com/?plan=captcha&user=l764191074&pass=gs4771822&topic=7001&author=test'
#     with open('./cap_union_new_getcapbysig.jpg', 'rb') as img:
#         image = img.read()
#     r = requests.post(url, data={'Base': base64.b64encode(image)})
#     pprint(r.json())