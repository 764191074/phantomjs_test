#! /usr/bin/env python2
# -*- encoding: utf8 -*-
import requests
from pyquery import PyQuery as pyq
import json
import ping
import socket
from operator import attrgetter
from retrying import retry
import logging
import logging.handlers
import re
import traceback
import base64
file_path = __file__.replace('get_ss_info.py', '{}')
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger("mylogger")
log.setLevel(logging.DEBUG)
h2 = logging.handlers.SMTPHandler(mailhost=('smtp.163.com', 25),
                            fromaddr='nrr2pe5@163.com',
                            toaddrs=['nrr2pe5@163.com', '764191074@qq.com'],
                            subject='警告：错误日志，希望尽快处理',
                            credentials=('nrr2pe5@163.com', 'zhipa8'),
                            secure=None)
h2.setLevel(logging.ERROR)
h2.setFormatter(formatter)
# h2.setFormatter(f)
log.addHandler(h2)

def request_get(url, *pr, **kwargs):


    return requests.get(url, timeout=5, verify=False, *pr, **kwargs)

def retry_if_io_error(exception):
    """Return True if we should retry (in this case when it's an IOError), False otherwise"""
    logging.warning(traceback.format_exc())


class SS(object):

    ss_list = []

    def __init__(self, ip_address=None, port=None, mm=None, jiami=None, delay=None, source_url=None):
        self.ip_address = ip_address
        self.port = port
        self.mm = mm
        self.jiami = jiami
        self.delay = delay
        self.source_url = source_url

    def ping(self):
        try:
            self.ip_address = socket.gethostbyname(self.ip_address)
            self.delay = ping.do_one(self.ip_address, 2, 16) or 2.0
            # self.delay = ping.Ping(self.ip_address, timeout=2000).do()
        except Exception as e:
            self.delay = 1.0

    @classmethod
    def sort_by_ping(cls):
        tmp_list = []
        for s in SS.ss_list:
            if all([s.ip_address, s.port, s.mm, s.jiami]):
                tmp_list.append(s)

        SS.ss_list = sorted(tmp_list, key=attrgetter('delay'))

    @classmethod
    def quchong(cls):
        tmp_list = []
        ip_lsit = []
        for s in SS.ss_list:
            if s in SS.ss_list:
                if s.ip_address not in ip_lsit:
                    tmp_list.append(s)
                    ip_lsit.append(s.ip_address)

        SS.ss_list = tmp_list


class GetSS(object):

    def __init__(self):
        pass

    def get_github_ss(self):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3004.3 Safari/537.36'
        }
        url = 'https://github.com/Alvin9999/new-pac/wiki/ss%E5%85%8D%E8%B4%B9%E8%B4%A6%E5%8F%B7'
        r = request_get(url, headers=headers)
        pattern = re.compile(r'服务器(.*?)：(.*?)  端口：(.*?) 密码：(.*?) 加密方式：(.*?)</p>')
        all_data = pattern.findall(r.text.encode('utf-8'))
        for item in all_data:
            ss = SS()
            ss.ip_address = item[1].strip()

            ss.port = item[2].strip()

            ss.mm = item[3].strip()

            ss.jiami = item[4].split('（')[0].decode('utf-8').strip()

            if u'混淆' in ss.jiami:
                continue
            ss.source_url = url

            ss.ping()
            SS.ss_list.append(ss)
        pass

    # @retry(stop_max_attempt_number=3, retry_on_exception=retry_if_io_error)
    def get_shadow_socks(self):
        # www.ishadowsocks.me
        url = 'https://b.ishadow.tech/'
        r = request_get(url, timeout=5)
        jpy = pyq(r.text)
        # items = [pyq(item) for item in jpy('div.col-sm-4.text-center')]
        items = jpy('div.col-sm-4.text-center')
        for item in list(items.items())[:3]:
            ss = SS()
            h4_list = item('h4')
            ss.ip_address = h4_list.eq(0).text()
            ss.ip_address = ss.ip_address.split(':')[1]

            ss.port = h4_list.eq(1).text()
            ss.port = ss.port.split(':')[1]

            ss.mm = h4_list.eq(2).text()
            ss.mm = ss.mm.split(':')[1]

            ss.jiami = h4_list.eq(3).text()
            ss.jiami = ss.jiami.split(':')[1]

            ss.source_url = url

            ss.ping()
            SS.ss_list.append(ss)

    # @retry(stop_max_attempt_number=3, retry_on_exception=retry_if_io_error)
    def get_ss_iyu_pub(self):
        # www.ishadowsocks.me
        url = 'http://ss.iyu.pub/'
        r = request_get(url)
        jpy = pyq(r.text)
        # items = [pyq(item) for item in jpy('div.col-sm-4.text-center')]
        items = jpy('div.col-sm-4.text-center')
        for item in list(items.items()):
            ss = SS()
            h4_list = item('h4')
            ss.ip_address = h4_list.eq(1).text()
            ss.ip_address = ss.ip_address.split(':')[1]

            ss.port = h4_list.eq(2).text()
            ss.port = ss.port.split(':')[1]

            ss.mm = h4_list.eq(3).text()
            ss.mm = ss.mm.split(':')[1]

            ss.jiami = h4_list.eq(4).text()
            ss.jiami = ss.jiami.split(':')[1]

            ss.source_url = url

            ss.ping()
            SS.ss_list.append(ss)

    @retry(stop_max_attempt_number=3)
    def get_freessr(self):
        # https://freessr.xyz/
        url = 'https://freessr.xyz/'
        r = request_get(url)
        jpy = pyq(r.text)
        items = [pyq(item) for item in jpy('div.col-md-6.text-center')]

        for item in items[:-1]:
            ss = SS()
            h4_list = item('h4')
            ss.ip_address = h4_list.eq(0).text()
            ss.ip_address = ss.ip_address.split(':')[1]

            ss.port = h4_list.eq(1).text()
            ss.port = ss.port.split(':')[1]

            ss.mm = h4_list.eq(2).text()
            ss.mm = ss.mm.split(':')[1]

            ss.jiami = h4_list.eq(3).text()
            ss.jiami = ss.jiami.split(':')[1]

            ss.source_url = url

            ss.ping()
            SS.ss_list.append(ss)

    @retry(stop_max_attempt_number=3)
    def get_freevpnss(self):
        # https://freevpnss.cc/
        url = 'https://get.freevpnss.me/'
        r = request_get(url)
        jpy = pyq(r.text)
        items = [pyq(item) for item in jpy('div.panel-body')[3:]]

        for item in items:
            ss = SS()
            h4_list = item('p')
            ss.ip_address = h4_list.eq(0).text()[18:]

            ss.port = h4_list.eq(1).text()[9:]

            ss.mm = h4_list.eq(2).text()[12:]

            ss.jiami = h4_list.eq(3).text()[15:]

            ss.source_url = url

            ss.ping()
            SS.ss_list.append(ss)

    @retry(stop_max_attempt_number=3)
    def get_51xiaoshuang(self):
        # https://51xiaoshuang.com/free-ss
        url = 'https://xsjs.yhyhd.org/free-ss'
        r = request_get(url)
        jpy = pyq(r.text)
        a = jpy('#ss-body > strong')
        items = [a[i:i + 4] for i in range(0, len(a), 4)]
        for item in items:
            ss = SS()
            ss.ip_address = item[0].text

            ss.port = item[1].text

            ss.mm = item[3].text

            ss.jiami = item[2].text

            ss.source_url = url

            ss.ping()
            SS.ss_list.append(ss)

    @retry(stop_max_attempt_number=3)
    def get_ashadowsocks(self):
        # https://www.ashadowsocks.com/tutorial/trial_port#free
        # return
        url = 'https://www.ashadowsocks.com/tutorial/get_ports'
        headers = {
            'Referer': 'https://www.ashadowsocks.com/tutorial/trial_port',
            'X-Requested-With': 'XMLHttpRequest',
        }
        json_data = requests.post(url, data='test=1', headers=headers).json()[1]

        for item in json_data:
            ss = SS()

            item = item['Port']

            ss.ip_address = item['sshost']

            ss.port = item['ssport']

            ss.mm = item['sspass']

            ss.jiami = item['ssencrypt']

            ss.source_url = url

            ss.ping()
            SS.ss_list.append(ss)

    @retry(stop_max_attempt_number=3)
    def get_17zz(self):
        # https://www.17zz.pw/
        return
        url = 'https://www.17zz.pw/'
        r = request_get(url)
        jpy = pyq(r.text)
        h4_list = jpy('#server_FREE > dt')

        ss = SS()

        ss.ip_address = h4_list.eq(0).text()
        ss.ip_address = ss.ip_address.split(':')[1]

        ss.port = h4_list.eq(1).text()
        ss.port = ss.port.split(':')[1]

        ss.mm = h4_list.eq(2).text()
        ss.mm = ss.mm.split(':')[1]

        ss.jiami = h4_list.eq(3).text()
        ss.jiami = ss.jiami.split(':')[1]

        ss.source_url = url

        ss.ping()
        SS.ss_list.append(ss)

    @retry(stop_max_attempt_number=3)
    def get_k111(self):
        return
        url = 'http://k111.tk/'
        r = request_get(url)
        from chardet import detect
        a = '服务器地址：'
        detect(a)

        ip_address_list = self.get_str_center_list(r.content.decode('utf-8'), '服务器地址：'.decode('utf-8'), '<br>'.decode('utf-8'))
        prot_list = self.get_str_center_list(r.content.decode('utf-8'), '连接端口：'.decode('utf-8'), '<br>'.decode('utf-8'))
        jiami_list = self.get_str_center_list(r.content.decode('utf-8'), '加密方式：'.decode('utf-8'), '<br>'.decode('utf-8'))
        mm_list = self.get_str_center_list(r.content.decode('utf-8'), '登录口令：'.decode('utf-8'), '<br>'.decode('utf-8'))
        for item in items:
            ss = SS()
            ss.ip_address = item[0].text

            ss.port = item[1].text

            ss.mm = item[3].text

            ss.jiami = item[2].text

            ss.source_url = url

            ss.ping()
            SS.ss_list.append(ss)

    @retry(stop_max_attempt_number=3)
    def get_seofangfa(self):
        # http://seofangfa.com/shadowsocks.html
        url = 'http://seofangfa.com/shadowsocks.html'
        r = request_get(url)
        jpy = pyq(r.text)
        items = [pyq(item) for item in jpy('div.col-lg-4.text-center')]

        for item in items:
            ss = SS()
            h4_list = item('h4')
            ss.ip_address = h4_list.eq(0).text()
            ss.ip_address = ss.ip_address.split(':')[1]

            ss.port = h4_list.eq(1).text()
            ss.port = ss.port.split(':')[1]

            ss.mm = h4_list.eq(2).text()
            ss.mm = ss.mm.split(':')[1]

            ss.jiami = 'aes-256-cfb'

            ss.source_url = url

            ss.ping()
            SS.ss_list.append(ss)

    def out_ss_json(self):
        tem = {
                    "configs": [
                    ],
                    "strategy": None,
                    "index": 0,
                    "global": False,
                    "enabled": True,
                    "shareOverLan": True,
                    "isDefault": False,
                    "localPort": 1080,
                    "pacUrl": None,
                    "useOnlinePac": False}

        for ss in SS.ss_list:
            try:
                ls = {
                    "server": ss.ip_address,
                    "server_port": int(ss.port) if ss.port.isalnum() else 80,
                    "password": ss.mm,
                    "method": ss.jiami,
                    "remarks": ss.source_url}
                tem['configs'].append(ls)
            except:
                continue
        str_json = json.dumps(tem, indent=4, sort_keys=False, ensure_ascii=False)

        with open(file_path.format('gui-config.json'), 'w') as f:
            f.write(str_json.encode('utf-8'))

    def start_cap(self):
        try:
            self.get_github_ss()
        except Exception as e:
            log.error(traceback.format_exc())


        try:
            self.get_shadow_socks()
        except Exception as e:
            log.error(traceback.format_exc())
            traceback.print_exc()

        try:
            self.get_freessr()
        except Exception as e:
            log.error(traceback.format_exc())
            traceback.print_exc()

        try:
            self.get_freevpnss()
        except Exception as e:
            log.error(traceback.format_exc())
            traceback.print_exc()

        try:
            self.get_51xiaoshuang()
        except Exception as e:
            log.error(traceback.format_exc())
            traceback.print_exc()

        try:
            self.get_ashadowsocks()
        except Exception as e:
            log.error(traceback.format_exc())
            traceback.print_exc()

        try:
            self.get_17zz()
        except Exception as e:
            log.error(traceback.format_exc())
            traceback.print_exc()

        try:
            self.get_k111()
        except Exception as e:
            log.error(traceback.format_exc())
            traceback.print_exc()

        try:
            self.get_dou_bi()
        except Exception as e:
            log.error(traceback.format_exc())
            traceback.print_exc()

        try:
            self.get_ss_iyu_pub()
        except Exception as e:
            log.error(traceback.format_exc())
            traceback.print_exc()
        # self.get_seofangfa()
        SS.quchong()
        SS.sort_by_ping()

        self.out_ss_json()

    @retry(stop_max_attempt_number=3)
    def get_dou_bi(self):
        # https://www.dou-bi.co/sszhfx/

        url = 'https://doub.bid/sszhfx/'
        r = request_get(url)
        ss_list = re.findall(r'ss://(.*?)"', r.text)

        for item in ss_list:
            try:
                decodestr = base64.b64decode(item)
                decodestr = decodestr.decode()
            except:
                continue
                # decodestr = base64.decodestring(item.encode('utf-8'))
                # decodestr = decodestr.decode()
            decodestr = decodestr.replace('@', ':')
            td_list = decodestr.split(':')
            ss = SS()

            ss.ip_address = td_list[2].strip()

            ss.port = td_list[3].strip()

            ss.mm = td_list[1].strip()

            ss.jiami = td_list[0].strip()

            ss.source_url = url

            ss.ping()
            SS.ss_list.append(ss)

    @retry(stop_max_attempt_number=3)
    def get_github(self):
        # https://www.dou-bi.co/sszhfx/

        url = 'https://github.com/Alvin9999/new-pac/wiki/ss%E5%85%8D%E8%B4%B9%E8%B4%A6%E5%8F%B7'
        r = request_get(url)
        # jpy = pyq(r.text)
        # items = [pyq(item) for item in jpy('table > tbody > tr')]
        items = re.findall(u'<p>服务器1(.*?) 端口(.*?) 密码(.*?) 加密方式(.*?)</p>'.decode('utf-8'), r.text)

        for item in items:
            pass


    def get_str_center(self, string,start_str, end_str):
        string_list = string.partition(start_str)
        if not string_list[2]:
            return None

        rtn_string = string_list[2].partition(end_str)
        if not rtn_string[2]:
            return None
        return rtn_string[0]

    def get_str_center_list(self, string, start_str, end_str):

        rtn_string_list = []
        while True:
            rtn_string = self.get_str_center(string, start_str, end_str)
            if not rtn_string:
                break
            rtn_string_list.append(rtn_string)
            temp_string = start_str + rtn_string + end_str
            string = string.replace(temp_string, '')
        return rtn_string_list


g = GetSS()
g.get_github_ss()
pass
