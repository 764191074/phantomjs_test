#! /usr/bin/env python3
# coding=utf-8
import logging
from yanzhengma import yanzhengma
import time
import selenium
from PIL import Image
import pyscreenshot as ImageGrab
import traceback
import requests
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import NoSuchElementException
from pprint import pprint
# 引入配置对象DesiredCapabilities
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from func_timeout import func_set_timeout
import func_timeout
from retrying import retry
dcap = dict(DesiredCapabilities.PHANTOMJS)
logger = logging.getLogger()
#从USER_AGENTS列表中随机选一个浏览器头，伪装浏览器
dcap["phantomjs.page.settings.userAgent"] = ('Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537'
                                             '.36 (KHTML, like Gecko) Chrome/58.0.3013.3 Safari/537.36')
# 不载入图片，爬页面速度会快很多
dcap["phantomjs.page.settings.loadImages"] = False
# 设置代理
service_args = ['--proxy=106.39.187.205:48123',
                '--proxy-type=http',
                "--proxy-auth=zs:eeL3sohmeefi0cae"
                ]
#打开带配置信息的phantomJS浏览器
phantomjs_driver_path = '/usr/bin/phantomjs'

driver = webdriver.PhantomJS(phantomjs_driver_path, desired_capabilities=dcap,
                             # service_args=service_args
                             )
driver.set_window_size(800, 800)


def get_html():
    url = 'https://2.taobao.com/item.htm?id=552799235432'
    cookies = {'CNZZDATA1252911424': '1015056835-1488934217-https%253A%252F%252Fwww.baidu.com%252F%7C1496738928',
                 'CNZZDATA30057895': 'cnzz_eid%3D1573481468-1488935289-https%253A%252F%252Fwww.baidu.com%252F%26ntime%3D1496741702',
                 'CNZZDATA30058279': 'cnzz_eid%3D1345882637-1488936765-https%253A%252F%252Fs.2.taobao.com%252F%26ntime%3D1496738638',
                 'CNZZDATA30065152': 'cnzz_eid%3D362400588-1494565746-https%253A%252F%252F2.taobao.com%252F%26ntime%3D1495673406',
                 'UM_distinctid': '15acfb645ee2f9-07dda74a0bc552-1e187458-2a3000-15acfb645efe79',
                 '_cc_': 'UIHiLt3xSw%3D%3D',
                 '_tb_token_': 'e835faedfee83',
                 'cna': 'ZSo9Ec5v/ScCAbYSAmS1i3WB',
                 'cookie2': '2cf978d2e6c08056134f0049290a54eb',
                 'hng': 'CN%7Czh-CN%7CCNY',
                 'isg': 'ApOTxjTIzoytA4MBbe0L7dPVIhe3SBAMlXocAkWx47LpxLJmzBloWsHeiANQ',
                 'l': 'Are3XdRMsOVGNgukjqgamPHZx6ED6Iv6',
                 'lgc': 'l764191074',
                 'miid': '933232841343141679',
                 'mt': 'np=&ci=3_1&cyk=-1_-1',
                 't': '1dce65f95534d0961c8ddab0dfa1739d',
                 'tg': '0',
                 'thw': 'cn',
                 'tracknick': 'l764191074',
                 'uc3': 'sg2=UNdaJ3RYyitV7F4h46WNzvT%2BwSpLtb0ufaYQ%2Bh7c%2BAk%3D&nk2=D5SztBBc3cTn%2BQ%3D%3D&id2=UoH8XffcnQ7C3Q%3D%3D&vt3=F8dARV5%2FGqdNZCwTWiY%3D&lg2=VFC%2FuZ9ayeYq2g%3D%3D',
                 'uss': 'AQXKYk%2FhhiIcRIgwvOIxRMiHYkX1%2Fcm8vGd5CkfHkjnr7DDnxZDrdmOAHA%3D%3D',
                 'v': '0',
                 'x': 'e%3D1%26p%3D*%26s%3D0%26c%3D0%26f%3D0%26g%3D0%26t%3D0%26__ll%3D-1%26_ato%3D0'}
    for k, v in cookies.items():
        driver.add_cookie({
            'domain': '.taobao.com',  # note the dot at the beginning
            'name': k,
            'value': v,
            'path': '/',
            'expires': None
        })
    driver.get(url)
    driver.save_screenshot('codingpy.png')
    return driver.title, driver.page_source

if __name__ == '__main__':
    get_html()